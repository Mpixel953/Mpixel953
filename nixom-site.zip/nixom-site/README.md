# Nixom Studio website

A single-page studio website. Everything (HTML, CSS, JavaScript, images and the launch video) is inside `index.html`, so it needs no build step.

## Publish with GitHub Pages
1. Push these files to a GitHub repository (branch `main`).
2. Repository **Settings → Pages**.
3. Under **Build and deployment**, choose **Deploy from a branch**, branch `main`, folder `/ (root)`, then **Save**.
4. After about a minute the site is live at `https://YOUR-USERNAME.github.io/REPOSITORY-NAME/`.

## Before going live, replace these placeholders in `index.html`
- `hello@yourstudio.com` (4 places: contact, forms, footer)
- `careers@yourstudio.com` (careers page)
- Social links in the footer (X and LinkedIn currently point to `#`)
